# Enhanced Signal Notifications Implementation

**日期**: 2026-02-26
**状态**: 已完成
**模块**: zero-trading/notification

---

## 概述

本次实现增强了 zero-trading 的信号通知功能，在原有基础信号消息上添加了执行建议、仓位建议、风险提示和时效性指示，使交易者能够更快速地做出决策。

## 实现内容

### 1. 增强的信号通知方法

在 `NotificationClient` 中新增 `send_trading_signal_with_recommendation()` 方法：

```rust
pub async fn send_trading_signal_with_recommendation(
    &self,
    signal: &TradingSignal,
    macro_env: Option<&MacroEnvironment>,
) -> Result<()>
```

### 2. 执行建议生成

根据信号强度和宏观环境生成执行建议：

| 信号强度 | 建议 |
|---------|------|
| VeryStrong | 极强信号，高置信度入场机会 |
| Strong | 强信号，可考虑标准仓位入场 |
| Medium | 中等信号，建议轻仓试探 |
| Weak | 弱信号，观望为主 |

宏观环境因素：
- Bullish: 宏观环境看多，支持做多信号
- Neutral: 宏观环境中性，按信号强度操作
- Bearish: 宏观环境偏空，做多信号需谨慎
- AvoidTrading: 宏观环境不利，建议暂缓操作

### 3. 仓位建议

基于信号强度和宏观系数计算建议仓位：

```
建议仓位 = min(基础仓位 × 宏观系数, 20%)

基础仓位:
- VeryStrong: 15%
- Strong: 10%
- Medium: 5%
- Weak: 0% (观望)
```

### 4. 风险提示

自动生成的风险提示包括：
- T+1规则提醒（A股当日买入次日方可卖出）
- 止损距离评估（>5%警告，3-5%正常，<3%良好）
- 风险回报比评估（≥3:1优质，≥2:1合理，<2:1偏低）

### 5. 时效性指示

根据信号生成时间显示时效状态：

| 信号年龄 | 状态 |
|---------|------|
| 0-5分钟 | 🔴 刚产生 - 可立即评估 |
| 6-15分钟 | 🟡 较新鲜 - 建议尽快评估 |
| 16-30分钟 | 🟢 有效期内 - 仍可考虑 |
| 31-60分钟 | ⚪ 即将过期 - 需确认是否仍有效 |
| >60分钟 | ⬜ 已过期 - 建议等待新信号 |

### 6. 策略扫描器集成

更新 `run_strategy_scanner()` 使用增强通知：

```rust
// Fetch macro environment for enhanced notifications
let macro_env = state.macro_filter.get_environment().await.ok();

// Send enhanced notifications
state.notification
    .send_trading_signal_with_recommendation(signal, macro_env.as_ref())
    .await
```

## 消息示例

```
🟢 *000001.SZ* 做多信号

📊 *信号强度:* ⭐⭐⭐
💰 *入场价:* 10.00
🛑 *止损:* 9.50 (5.0%)
🎯 *目标:* 12.00 (20.0%)
📈 *风险回报:* 4.0:1
⏰ *周期共振:* Daily, H4

📐 *PO3结构:*
  - 阶段: Distribution
  - 中轴线: 10.75

🌍 *宏观环境*
周期阶段: Expansion
交易偏向: Bullish
仓位系数: 1.2x
备注: PMI: 52.5 | M2同比: 10.5%

━━━━━━━━━━━━━━━━━━━━━━━━━━

📋 *执行建议*
强信号，可考虑标准仓位入场 | 宏观环境看多，支持做多信号

💰 *仓位建议*
建议仓位: 12% (基础10% × 宏观系数1.2)

⚠️ *风险提示*
📌 A股T+1: 今日买入明日方可卖出
💡 正常风险: 止损距离适中，严格执行
⭐ 优质R:R: 风险回报比≥3:1

⏰ *时效性* 🔴 刚产生 - 可立即评估

━━━━━━━━━━━━━━━━━━━━━━━━━━
_此信号仅供参考，不构成投资建议_
```

## 测试覆盖

新增 14 个单元测试验证所有功能：

- `test_execution_recommendation_strong_bullish`
- `test_execution_recommendation_weak_bearish`
- `test_execution_recommendation_no_macro`
- `test_position_suggestion_very_strong`
- `test_position_suggestion_weak`
- `test_position_suggestion_capped_at_20`
- `test_risk_tips_high_risk`
- `test_risk_tips_good_rr`
- `test_urgency_indicator_fresh`
- `test_enhanced_message_format`
- `test_enhanced_message_without_macro`

## 修改的文件

1. `services/zero-trading/src/notification.rs` - 新增增强通知方法和测试
2. `services/zero-trading/src/lib.rs` - 集成增强通知到策略扫描器

## 后续优化建议

1. **信号确认机制** (中优先级)
   - 支持 Telegram inline keyboard 交互式确认
   - 记录用户决策到日志

2. **实时价格监控** (中优先级)
   - 评估是否需要 WebSocket 实时行情
   - 当前 1 分钟 K 线间隔对于止损触发可能有延迟

3. **个性化设置** (低优先级)
   - 允许用户配置通知详细程度
   - 支持关闭特定类型的提示
